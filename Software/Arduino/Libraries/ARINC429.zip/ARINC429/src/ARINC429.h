// ARINC429.h - codificacion/decodificacion de palabras ARINC 429.
//
// Implementa la capa de palabra (formato, etiquetas, BNR, SSM,
// paridad) del estandar ARINC 429 / Mark 33 DITS. La capa fisica
// diferencial bipolar NO sera implementada. Las palabras son de
// 32 bits y se pueden enviar por el transporte que se quiera (NRF24,
// UART, SPI, transceiver real como HI-3593...).
//
// Formato de palabra (32 bits):
//   bits 0-7   label  (etiqueta, 8 bits, octal)
//   bits 8-9   SDI    (Source/Destination Identifier)
//   bits 10-28 data   (19 bits utiles)
//   bits 29-30 SSM    (Sign/Status Matrix)
//   bit  31    parity (paridad impar)
//
// Uso basico:
//   #include <ARINC429.h>
//
//   uint32_t w = ARINC429::buildBNR(A429_LABEL_PITCH, 0, 30.0f,
//                                   A429_LSB_ANGLE_DEG,
//                                   A429_SSM_BNR_NORMAL);
//   ...
//   uint8_t label, ssm;
//   bool valid;
//   float pitch = ARINC429::parseBNR(w, A429_LSB_ANGLE_DEG,
//                                    label, ssm, valid);
//
// Referencias:
//   ARINC Specification 429 Part 1-17 -- Functional Description,
//     Electrical Interface, Label Assignments and Word Formats
//   AIM "ARINC 429 Tutorial" v2.2, 2019 (BNR, SSM, parity)
//   ARINC 429 Part 1, Attachment 2 -- tabla de parametros con sus
//     escalas, ranges y tasas de refresco

#ifndef ARINC429_H
#define ARINC429_H

#include <Arduino.h>

// Etiquetas estandar (en octal). Lista parcial -- las que usa el TFG.
// La spec completa esta en ARINC 429 Part 1, Attachment 2.
#define A429_LABEL_PITCH         0324  // Pitch Angle      - BNR +/-180 deg
#define A429_LABEL_ROLL          0325  // Roll Angle       - BNR +/-180 deg
#define A429_LABEL_HDG_MAG       0320  // Magnetic Heading - BNR +/-180 deg
#define A429_LABEL_PRES_ALT      0204  // Pressure Altitude - BNR ft
#define A429_LABEL_VERT_SPEED    0365  // Vertical Speed   - BNR ft/min
#define A429_LABEL_LATITUDE      0310  // Present Position Lat - BNR deg
#define A429_LABEL_LONGITUDE     0311  // Present Position Lon - BNR deg
#define A429_LABEL_GPS_ALT       0076  // GPS Altitude (MSL) - BNR ft
#define A429_LABEL_RADIO_ALT     0164  // Radio Altitude   - BNR ft
#define A429_LABEL_RADAR_DIST    0166  // No estandar (libre). Distancia radar.
#define A429_LABEL_STATUS        0270  // No estandar. Status discrete custom.

// SSM para BNR (bits 29-30)
#define A429_SSM_BNR_FAILURE     0x0   // Failure Warning
#define A429_SSM_BNR_NO_DATA     0x1   // No Computed Data
#define A429_SSM_BNR_TEST        0x2   // Functional Test
#define A429_SSM_BNR_NORMAL      0x3   // Normal Operation

// Escalas BNR (unidades por LSB).
// Calculadas como rango_completo / 2^18 para 18 bits utiles + 1 de signo.
#define A429_LSB_ANGLE_DEG       (180.0f / 262144.0f)  // 6.866e-4 deg/LSB
#define A429_LSB_PRES_ALT_FT     0.5f                  // +/- 131072 ft
#define A429_LSB_GPS_ALT_FT      0.5f                  // igual que pres alt
#define A429_LSB_VSPEED_FPM      0.125f                // +/- 32768 fpm
#define A429_LSB_RADIO_ALT_FT    0.0625f               // +/- 16384 ft
#define A429_LSB_RADAR_DIST_M    0.01f                 // +/- 2621 m

// Palabra "vacia": label = 0, SSM = NO_DATA. Sirve como relleno de
// slots cuando el transmisor no tiene nada que mandar. El receptor la
// reconoce por label = 0 y la descarta.
#define A429_EMPTY_WORD          0x20000000UL

// Constructor / parser de palabras ARINC 429
class ARINC429 {
public:
  // Construye una palabra BNR de 32 bits con paridad impar.
  static uint32_t buildBNR(uint8_t label, uint8_t sdi,
                           float value, float lsb, uint8_t ssm);

  // Construye una palabra discrete (sin escala, 19 bits crudos).
  static uint32_t buildDiscrete(uint8_t label, uint8_t sdi,
                                uint32_t data19, uint8_t ssm);

  // Decodifica una palabra BNR. valid = paridad OK y SSM = NORMAL.
  static float parseBNR(uint32_t word, float lsb,
                        uint8_t &label_out, uint8_t &ssm_out, bool &valid);

  // Decodifica una palabra discrete.
  static uint32_t parseDiscrete(uint32_t word,
                                uint8_t &label_out, uint8_t &ssm_out,
                                bool &valid);

  // Comprueba paridad impar (32 bits).
  static bool checkParity(uint32_t word);

private:
  static uint32_t pack(uint8_t label, uint8_t sdi,
                       uint32_t data19, uint8_t ssm);
  static uint8_t oddParityBit(uint32_t w);
};

#endif
