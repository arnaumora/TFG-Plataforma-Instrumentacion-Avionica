// ARINC429.cpp - implementacion del builder/parser ARINC 429.

#include "ARINC429.h"

// Trunca un float al rango representable por un entero de 19 bits con
// signo (-2^18 .. 2^18 - 1) y devuelve la representacion en
// complemento a dos sobre 19 bits. Si esta fuera de rango se satura.
static uint32_t toData19Signed(long scaled) {
  if (scaled >  262143) scaled =  262143;   //  2^18 - 1
  if (scaled < -262144) scaled = -262144;   // -2^18
  return ((uint32_t)scaled) & 0x7FFFF;       // mascara 19 bits
}

uint32_t ARINC429::pack(uint8_t label, uint8_t sdi,
                        uint32_t data19, uint8_t ssm) {
  uint32_t w = 0;
  w |= (uint32_t)label;                      // bits 0-7
  w |= (uint32_t)(sdi   & 0x03) << 8;        // bits 8-9
  w |= (uint32_t)(data19 & 0x7FFFF) << 10;   // bits 10-28
  w |= (uint32_t)(ssm   & 0x03) << 29;       // bits 29-30
  return w;
}

// Paridad impar sobre los 32 bits via XOR-fold + lookup en mascara
// 0x6996. El lookup (0x6996 >> nibble) & 1 devuelve 1
// si el popcount del valor original (antes del fold) es IMPAR. Asi
// que para un dato cuyos bits de paridad acumulada (despues del fold)
// dan 0 (popcount par), hay que devolver 1 para que el total sea impar.
uint8_t ARINC429::oddParityBit(uint32_t w) {
  uint32_t x = w;
  x ^= x >> 16;
  x ^= x >> 8;
  x ^= x >> 4;
  x &= 0xF;
  uint8_t inputIsOdd = (0x6996 >> x) & 1;
  // Si el dato ya tiene popcount impar, parity=0 deja el total impar.
  // Si el dato tiene popcount par, parity=1 lo hace impar.
  return (inputIsOdd == 1) ? 0 : 1;
}

uint32_t ARINC429::buildBNR(uint8_t label, uint8_t sdi,
                            float value, float lsb, uint8_t ssm) {
  // Escala a LSBs y redondea al entero mas cercano
  long scaled = lroundf(value / lsb);
  uint32_t data19 = toData19Signed(scaled);

  uint32_t w = pack(label, sdi, data19, ssm);
  uint8_t parity = oddParityBit(w);
  return w | ((uint32_t)parity << 31);
}

uint32_t ARINC429::buildDiscrete(uint8_t label, uint8_t sdi,
                                 uint32_t data19, uint8_t ssm) {
  uint32_t w = pack(label, sdi, data19 & 0x7FFFF, ssm);
  uint8_t parity = oddParityBit(w);
  return w | ((uint32_t)parity << 31);
}

bool ARINC429::checkParity(uint32_t word) {
  // La palabra ya incluye su bit de paridad. Si la paridad es correcta,
  // el numero total de unos en los 32 bits sera impar (paridad impar).
  // El truco 0x6996 con xor-fold devuelve 1 si el popcount es IMPAR,
  // que es exactamente lo que queremos verificar.
  uint32_t x = word;
  x ^= x >> 16;
  x ^= x >> 8;
  x ^= x >> 4;
  x &= 0xF;
  uint8_t totalIsOdd = (0x6996 >> x) & 1;
  return totalIsOdd == 1;
}

float ARINC429::parseBNR(uint32_t word, float lsb,
                         uint8_t &label_out, uint8_t &ssm_out, bool &valid) {
  label_out = (uint8_t)(word & 0xFF);
  ssm_out   = (uint8_t)((word >> 29) & 0x03);
  valid     = checkParity(word) && (ssm_out == A429_SSM_BNR_NORMAL);

  // Extrae los 19 bits del campo de datos como entero con signo
  uint32_t data19 = (word >> 10) & 0x7FFFF;
  // Sign-extend a 32 bits: si el bit 18 esta a 1 el numero es negativo
  int32_t signed19;
  if (data19 & 0x40000) {
    signed19 = (int32_t)(data19 | 0xFFF80000);  // rellena con 1s
  } else {
    signed19 = (int32_t)data19;
  }
  return signed19 * lsb;
}

uint32_t ARINC429::parseDiscrete(uint32_t word,
                                 uint8_t &label_out, uint8_t &ssm_out,
                                 bool &valid) {
  label_out = (uint8_t)(word & 0xFF);
  ssm_out   = (uint8_t)((word >> 29) & 0x03);
  valid     = checkParity(word) && (ssm_out == A429_SSM_BNR_NORMAL);
  return (word >> 10) & 0x7FFFF;
}
