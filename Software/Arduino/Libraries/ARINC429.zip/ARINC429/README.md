# ARINC429

ARINC 429 word builder/parser library for Arduino. Implements the
logical layer of ARINC Specification 429 / Mark 33 DITS (word format,
label assignments, BNR/discrete encoding, SSM, odd parity).

The differential bipolar physical layer is **not** implemented. Words
are 32-bit values that can be transported over any link: NRF24L01,
UART, SPI, or a real ARINC 429 transceiver IC like the HI-3593.

## Installation

Copy the `ARINC429/` folder into your Arduino `libraries/` directory:

- Windows: `Documents\Arduino\libraries\ARINC429\`
- macOS:   `~/Documents/Arduino/libraries/ARINC429/`
- Linux:   `~/Arduino/libraries/ARINC429/`

Restart the Arduino IDE. The library should appear under
**Sketch -> Include Library -> ARINC429** and the example under
**File -> Examples -> ARINC429 -> SelfTest**.

## Quick start

```cpp
#include <ARINC429.h>

uint32_t w = ARINC429::buildBNR(A429_LABEL_PITCH, 0, 30.0f,
                                A429_LSB_ANGLE_DEG,
                                A429_SSM_BNR_NORMAL);

uint8_t label, ssm;
bool valid;
float pitch = ARINC429::parseBNR(w, A429_LSB_ANGLE_DEG,
                                 label, ssm, valid);
```

## References

- ARINC Specification 429 Part 1-17, Functional Description, Electrical
  Interface, Label Assignments and Word Formats
- AIM "ARINC 429 Tutorial" v2.2, 2019

## License

MIT (free to reuse, no warranty).
